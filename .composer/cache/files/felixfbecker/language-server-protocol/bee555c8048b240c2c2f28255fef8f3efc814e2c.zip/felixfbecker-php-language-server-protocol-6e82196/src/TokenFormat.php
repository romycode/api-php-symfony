<?php

namespace LanguageServerProtocol;

abstract class TokenFormat
{
    const RELATIVE = 'relative';
}
