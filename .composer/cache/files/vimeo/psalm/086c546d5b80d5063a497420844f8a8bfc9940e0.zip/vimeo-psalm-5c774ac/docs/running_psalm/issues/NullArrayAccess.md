# NullArrayAccess

Emitted when trying to access an array value on `null`

```php
<?php

$arr = null;
echo $arr[0];
```
