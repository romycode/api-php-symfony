# MissingDocblockType

Emitted when a docblock is present, but the type is missing or badly formatted

```php
<?php

/** @var $a */
$a = [];
```
