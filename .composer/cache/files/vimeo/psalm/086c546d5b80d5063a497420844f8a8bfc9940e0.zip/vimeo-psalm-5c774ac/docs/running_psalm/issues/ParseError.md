# ParseError

Emitted when the PHP Parser encounters an error.

```php
<?php

class A {
  public function foo() : void {
    echo "foo"
  }
}
```
