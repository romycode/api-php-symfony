# UndefinedMethod

Emitted when calling a method that does not exist

```php
<?php

class A {}
A::foo();
```
