# StringIncrement

Emitted when attempting to increment a string - this works in PHP, but is unexpected behaviour for most people.

```php
<?php

$a = "hello";
$a++;
```
