# ConfigIssue

Emitted for non-fatal configuration issues, e.g. deprecated configuration switches.

## Why this is bad

Your config file may be incompatible with future Psalm versions.
