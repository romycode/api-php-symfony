# InvalidPropertyFetch

Emitted when attempting to get a property from a non-object

```php
<?php

$a = "foo";
echo $a->bar;
```
