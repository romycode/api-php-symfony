# UndefinedInterface

Emitted when referencing an interface that does not exist but does have an identically-named class.

```php
<?php

class C {}

interface I extends C {}
```
