# ReservedWord

Emitted when using a reserved word as a class name

```php
<?php

function foo(resource $res) : void {}
```
