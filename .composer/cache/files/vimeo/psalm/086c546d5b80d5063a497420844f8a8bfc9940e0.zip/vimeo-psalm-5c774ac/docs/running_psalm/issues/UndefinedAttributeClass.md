# UndefinedAttributeClass

Emitted when referencing an attribute class that does not exist

```php
<?php
use Foo\Bar\Pure;

#[Pure]
class Video {}
```
