# MixedClone

Emitted when trying to clone a value whose type is not known

```php
<?php

$a = clone $GLOBALS["a"];
```
