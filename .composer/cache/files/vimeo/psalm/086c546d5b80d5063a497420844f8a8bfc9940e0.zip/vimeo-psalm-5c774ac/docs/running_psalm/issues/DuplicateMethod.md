# DuplicateMethod

Emitted when a method is defined twice

```php
<?php

class A {
    public function foo() {}
    public function foo() {}
}
```
