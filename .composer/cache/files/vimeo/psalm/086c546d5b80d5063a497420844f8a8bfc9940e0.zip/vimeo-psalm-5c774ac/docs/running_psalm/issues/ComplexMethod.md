# ComplexMethod

Emitted when a method is too complicated. Complicated methods should be split up.
