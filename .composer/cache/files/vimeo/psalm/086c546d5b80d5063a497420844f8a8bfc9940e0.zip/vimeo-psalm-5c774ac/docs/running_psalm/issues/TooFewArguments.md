# TooFewArguments

Emitted when calling a function with fewer arguments than the function has parameters

```php
<?php

function foo(string $a) : void {}
foo();
```
