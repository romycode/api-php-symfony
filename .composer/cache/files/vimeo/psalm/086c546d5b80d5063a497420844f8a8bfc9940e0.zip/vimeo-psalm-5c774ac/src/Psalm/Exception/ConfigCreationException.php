<?php

namespace Psalm\Exception;

use Exception;

final class ConfigCreationException extends Exception
{
}
