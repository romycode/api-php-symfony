<?php

namespace Psalm\Exception;

use Exception;

final class UnanalyzedFileException extends Exception
{
}
