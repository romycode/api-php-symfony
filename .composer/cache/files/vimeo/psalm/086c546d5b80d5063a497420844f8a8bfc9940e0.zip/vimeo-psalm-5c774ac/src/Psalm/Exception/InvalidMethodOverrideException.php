<?php

namespace Psalm\Exception;

use Exception;

final class InvalidMethodOverrideException extends Exception
{
}
