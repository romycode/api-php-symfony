<?php

namespace Psalm\Exception;

final class ConfigNotFoundException extends ConfigException
{
}
