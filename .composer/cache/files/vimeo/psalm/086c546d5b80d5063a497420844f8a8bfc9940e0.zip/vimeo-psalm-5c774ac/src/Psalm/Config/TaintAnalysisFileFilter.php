<?php

namespace Psalm\Config;

/** @internal */
final class TaintAnalysisFileFilter extends FileFilter
{
}
