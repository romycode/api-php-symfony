<?php

namespace Psalm\Exception;

use Exception;

final class TypeParseTreeException extends Exception
{
}
