<?php

namespace Psalm\Exception;

use Exception;

final class UnpreparedAnalysisException extends Exception
{
}
