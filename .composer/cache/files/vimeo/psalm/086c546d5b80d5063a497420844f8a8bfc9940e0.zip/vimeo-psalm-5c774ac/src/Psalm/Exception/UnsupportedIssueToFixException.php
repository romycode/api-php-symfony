<?php

namespace Psalm\Exception;

use Exception;

final class UnsupportedIssueToFixException extends Exception
{

}
