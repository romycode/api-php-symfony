<?php

namespace Psalm\Exception;

use Exception;

final class ComplicatedExpressionException extends Exception
{
}
