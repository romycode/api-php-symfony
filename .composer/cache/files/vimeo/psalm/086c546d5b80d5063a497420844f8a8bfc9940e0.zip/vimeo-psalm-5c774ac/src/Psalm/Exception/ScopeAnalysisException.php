<?php

namespace Psalm\Exception;

use Exception;

final class ScopeAnalysisException extends Exception
{
}
