<?php

namespace Psalm\Exception;

final class IncorrectDocblockException extends DocblockParseException
{
}
