<?php

namespace Psalm\Exception;

use Exception;

final class CodeException extends Exception
{
}
