<?php

namespace Psalm\Exception;

use Exception;

final class RefactorException extends Exception
{
}
