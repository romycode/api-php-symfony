<?php

namespace Psalm\Exception;

use Exception;

final class CircularReferenceException extends Exception
{
}
