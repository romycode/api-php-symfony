<?php

namespace Psalm\SymfonyPsalmPlugin\Exception;

class TemplateNameUnresolvedException extends \RuntimeException
{
}
