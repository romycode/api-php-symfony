<?php

namespace Psalm\SymfonyPsalmPlugin\Exception;

class InvalidConsoleModeException extends \InvalidArgumentException
{
}
