<?php

namespace Doctrine\DBAL\Tools\Console;

use OutOfBoundsException;

final class ConnectionNotFound extends OutOfBoundsException
{
}
