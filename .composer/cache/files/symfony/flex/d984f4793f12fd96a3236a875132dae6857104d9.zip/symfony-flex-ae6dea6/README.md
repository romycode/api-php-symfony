<p align="center"><a href="https://symfony.com" target="_blank">
    <img src="https://symfony.com/logos/symfony_black_02.svg">
</a></p>

[Symfony Flex][1] helps developers create [Symfony][2] applications, from the most
simple micro-style projects to the more complex ones with dozens of
dependencies.

[1]: https://symfony.com/doc/current/setup/flex.html
[2]: https://symfony.com
