CHANGELOG
=========

6.3
---

 * Add `ClockAwareTrait` to help write time-sensitive classes
 * Add `Clock` class and `now()` function

6.2
---

 * Add the component
