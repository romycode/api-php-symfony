Sponsor
-------

The test pack for Symfony 6.1/6.2 is [backed][1] by [Endava][2].

Endava is reimagining the relationship between people and technology.
By leveraging next-generation technologies, our agile, multi-disciplinary
teams provide a combination of Product & Technology Strategies, Intelligent
Experiences, and World Class Engineering to help our clients become more
engaging, responsive, and efficient.

Help Symfony by [sponsoring][3] its development!

[1]: https://symfony.com/backers
[2]: https://www.endava.com
[3]: https://symfony.com/sponsor
